<!DOCTYPE html>
<html lang="en">

<head>
	<title>Car Dealership</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="This document is a car dealership for the final project.">
	<meta name="author" content="Scott Shannon">
	<link rel='icon' type='image/png' href='/~shannonscotta/csci102/project/images/favicon.png'>
	<link rel='stylesheet' href="styles/stylesproject.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Spectral:wght@200&display=swap" rel="stylesheet"> </head>

<body>
	<header> <img src="https://chelan.highline.edu/~shannonscotta/csci102/project/images/teslalogo.png" alt="Tesla logo with unique color scheme" class="responsive">
		<nav>
			<ul>
				<li><a href="indexproject.php">Home</a></li>
				<li><a href="contactproject.php">Contact</a></li>
				<li><a href="locationproject.php">Location</a></li>
				<li><a href="inventoryproject.php">Inventory</a></li>
				<li><a href="financeproject.php">Finance</a></li>
				<li><a href="mediaproject.php">Media</a></li>
				<li><a href="aboutproject.php">About</a></li>
			</ul>
		</nav>
	</header>