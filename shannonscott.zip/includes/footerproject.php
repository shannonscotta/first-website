<footer>
	<script src="https://chelan.highline.edu/~shannonscotta/csci102/project/projectscript.js">
	</script>
	<ul>
		<li>
			<a href="https://www.facebook.com/teslaofficial" target="_blank"><img src="https://chelan.highline.edu/~shannonscotta/csci102/project/images/facebook.jpg" alt="facebook widget icon"></a>
		</li>
		<li>
			<a href="https://www.instagram.com/teslamotors" target="_blank"><img src="https://chelan.highline.edu/~shannonscotta/csci102/project/images/instagram.jpg" alt="instagram widget icon"></a>
		</li>
		<li>
			<a href="http://www.twitter.com/tesla" target="_blank"><img src="https://chelan.highline.edu/~shannonscotta/csci102/project/images/twitter.jpg" alt="twitter widget icon"></a>
		</li>
	</ul>
</footer>
</body>

</html>