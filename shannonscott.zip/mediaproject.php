<?php
   $title = "Media page";
   $description = "This document contains videos of our vehicles"; // (1) Set the title
   $author = "Scott Shannon";
   
   include "includes/headerproject.php"; 
   ?>
	<br>
	<iframe width="420" height="315" src="https://www.youtube.com/embed/jWreyC2l-dw?mute=1"> </iframe>
	<br>
	<iframe width="420" height="315" src="https://www.youtube.com/embed/azUbCdcAeFM?mute=1"> </iframe>
	<br>
	<iframe width="420" height="315" src="https://youtube.com/embed/v27iBE5qs5c?mute=1"> </iframe>
	<?php
   include "includes/footerproject.php";                
   ?>