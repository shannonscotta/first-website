<?php
   $title = "Car dealer home page";
   $description = "This document is the index page for the final project."; // (1) Set the title
   $author = "Scott Shannon";
   
   include "includes/headerproject.php"; 
   ?>
	<section>
		<h2>
   <img src="https://chelan.highline.edu/~shannonscotta/csci102/project/images/tesla.png" id="tesla" alt="a picture of a new tesla" class="responsive"> 
	</h2> </section>
	<?php
   include "includes/footerproject.php";                
   ?>